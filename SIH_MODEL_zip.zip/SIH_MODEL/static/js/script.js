document.addEventListener('DOMContentLoaded', function() {
    var complaintBtn = document.getElementById('complaintBtn');
    var complaintForm = document.getElementById('complaintForm');
    
    complaintBtn.addEventListener('click', function() {
        if (complaintForm.style.display === 'none' || complaintForm.style.display === '') {
            complaintForm.style.display = 'block';
        } else {
            complaintForm.style.display = 'none';
        }
    });

    var uploadAnotherBtn = document.getElementById('uploadAnotherBtn');
    uploadAnotherBtn.addEventListener('click', function() {
        window.location.href = '/';  // Redirect to the homepage or reset form
    });
});
